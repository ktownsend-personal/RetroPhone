var searchData=
[
  ['band',['band',['../class_multi_resonant_filter.html#a93c35829c63addc2f54f42ca3b30b37e',1,'MultiResonantFilter']]],
  ['bpmtomillis',['BPMtoMillis',['../group__util.html#ga44c238e75b5951fafcf0d7e9d3cafadb',1,'BPMtoMillis(float bpm):&#160;mozzi_utils.cpp'],['../group__util.html#ga44c238e75b5951fafcf0d7e9d3cafadb',1,'BPMtoMillis(float bpm):&#160;mozzi_utils.cpp']]]
];
