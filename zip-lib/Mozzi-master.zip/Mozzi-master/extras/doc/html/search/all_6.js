var searchData=
[
  ['getaudioinput',['getAudioInput',['../group__analog.html#ga3f15eb8d6694020d170ebcbedb645de7',1,'getAudioInput():&#160;MozziGuts.cpp'],['../group__analog.html#ga3f15eb8d6694020d170ebcbedb645de7',1,'getAudioInput():&#160;MozziGuts.cpp']]],
  ['getmax',['getMax',['../class_auto_range.html#a4d27e5fe43f9b376b537def88ac74119',1,'AutoRange']]],
  ['getmean',['getMean',['../class_rolling_stat.html#a8521a53cde7c5d28ac9c375aaee3a972',1,'RollingStat']]],
  ['getmin',['getMin',['../class_auto_range.html#acd1dae6e6ffb288efc1618e2453ad5ef',1,'AutoRange']]],
  ['getphasefractional',['getPhaseFractional',['../class_meta_oscil.html#a20f0dcb30669eee21bfaa237f038c35d',1,'MetaOscil::getPhaseFractional()'],['../class_oscil.html#aa774ef68b06f9652e6ac23d4e9332554',1,'Oscil::getPhaseFractional()']]],
  ['getrange',['getRange',['../class_auto_range.html#a75c842b27ad3917be6d29e3d35b485f3',1,'AutoRange']]],
  ['getstandarddeviation',['getStandardDeviation',['../class_rolling_stat.html#a234ab1d244e4b392056fcaa1fc1e4fc4',1,'RollingStat']]],
  ['getvariance',['getVariance',['../class_rolling_stat.html#a3e7e5f706e3b5ac2496f14b7b639775d',1,'RollingStat']]]
];
