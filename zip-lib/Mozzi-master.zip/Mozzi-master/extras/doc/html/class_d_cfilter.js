var class_d_cfilter =
[
    [ "DCfilter", "class_d_cfilter.html#ab55e871fc9d11dfb9231e44627181c2c", null ],
    [ "next", "class_d_cfilter.html#ae900f943d9520fbf3a522508231d82b0", null ]
];